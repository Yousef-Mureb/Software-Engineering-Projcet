/**
 * 
 */
/**
 * @author omarq
 *
 */
module coe420_project {
	requires org.junit.jupiter.api;
}