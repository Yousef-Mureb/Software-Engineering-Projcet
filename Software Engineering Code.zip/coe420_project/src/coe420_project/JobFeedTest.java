	package coe420_project;
	
	import org.junit.jupiter.api.BeforeEach;
	import org.junit.jupiter.api.Test;
	import static org.junit.jupiter.api.Assertions.*;
	
	import java.io.ByteArrayOutputStream;
	
	class JobFeedTest {
	    private JobFeed jobListingSystem;
	    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();
	
	    @BeforeEach
	    void setUp() {
	        jobListingSystem = new JobFeed();
	    }
	
	    @Test
	    void testPostJob() {
	        jobListingSystem.postJob("Software Developer", "Details of the job", "2 years", "3.0", "Bachelor's Degree", "New York");
	        assertEquals(1, jobListingSystem.getJobList().size(), "Job list should have 1 job after posting");
	
	        Job postedJob = jobListingSystem.getJobList().get(0);
	        assertEquals("Software Developer", postedJob.getTitle(), "Job title should match");
	        assertEquals("Details of the job", postedJob.getJobdetails(), "Job details should match");
	        // Add assertions for other attributes as well
	    }
	
	    @Test
	    void testDisplayJobsWithJobs() {
	        jobListingSystem.postJob("Software Developer", "Develop software", "2 years", "3.5", "Bachelor's Degree", "New York");
	        jobListingSystem.displayJobs();
	        
	        String expectedOutput = """
	            Current Job Listings:
	            ------------------------------
	            Job{title='Software Developer', jobDetails='Develop software', requiredWorkYears='2 years', requiredGPA='3.5', requiredEducation='Bachelor's Degree', location='New York'}
	            ------------------------------
	            """;
	
	        assertEquals(expectedOutput, outContent.toString(), "Output should display the job details correctly");
	    }
	    
	    @Test
	    void testDisplayJobsWithNoJobs() {
	        jobListingSystem.displayJobs();
	        String expectedOutput = "No jobs posted yet.\n";
	        assertEquals(expectedOutput, outContent.toString(), "Output should indicate no jobs are posted");
	    }
	}
