package coe420_project;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserManagerTest {

	
	 @BeforeEach
	    void setUp() {
	        UserManager inst = new UserManager();
	    }
	 
	 
	 @Test
	    void testCreateUserWithNewUsername() {
	        assertTrue(UserManager.createUser("newUser", "passwordHash", "userType"),
	                   "Creating a new user should return true");
	    }

	    @Test
	    void testCreateUserWithExistingUsername() {
	        UserManager.createUser("existingUser", "passwordHash", "userType");
	        assertFalse(UserManager.createUser("existingUser", "anotherPasswordHash", "userType"),
	                    "Creating a user with an existing username should return false");
	    }
	    
	    @Test
	    void testLoginWithValidCredentials() {
	        assertTrue(UserManager.login("testUser", "testPass"),
	                   "Logging in with valid credentials should return true");
	    }

	    @Test
	    void testLoginWithIncorrectPassword() {
	        assertFalse(UserManager.login("testUser", "wrongPass"),
	                    "Logging in with an incorrect password should return false");
	    }
}
