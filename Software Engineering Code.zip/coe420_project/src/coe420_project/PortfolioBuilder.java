package coe420_project;

import java.util.Scanner;

public class PortfolioBuilder {
    private Scanner scanner;
    private Portfolio portfolio;

    public PortfolioBuilder() {
        this.scanner = new Scanner(System.in);
    }

    public void buildPortfolio(Portfolio existingPortfolio) {
        this.portfolio = existingPortfolio != null ? existingPortfolio : new Portfolio();

        System.out.println("Portfolio Builder:");
        System.out.println("1. Create Portfolio");
        System.out.println("2. Edit Portfolio");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                createPortfolio();
                break;
            case 2:
                editPortfolio();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private void createPortfolio() {
        System.out.print("Enter work experience: ");
        String workExperience = scanner.nextLine();

        System.out.print("Enter GPA: ");
        String gpa = scanner.nextLine();

        System.out.print("Enter education: ");
        String education = scanner.nextLine();

        portfolio.addExperience(workExperience);
        portfolio.setGPA(gpa);
        portfolio.setEducation(education);

        System.out.println("Portfolio created successfully.");
    }

    private void editPortfolio() {
        System.out.println("Edit Portfolio:");
        System.out.println("1. Add Work Experience");
        System.out.println("2. Update GPA");
        System.out.println("3. Update Education");
        System.out.print("Enter your choice: ");
        int editChoice = scanner.nextInt();
        scanner.nextLine();

        switch (editChoice) {
            case 1:
                System.out.print("Enter additional work experience: ");
                String additionalWorkExperience = scanner.nextLine();
                portfolio.addExperience(additionalWorkExperience);
                break;
            case 2:
                System.out.print("Enter updated GPA: ");
                String updatedGPA = scanner.nextLine();
                portfolio.setGPA(updatedGPA);
                break;
            case 3:
                System.out.print("Enter updated education: ");
                String updatedEducation = scanner.nextLine();
                portfolio.setEducation(updatedEducation);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }

        System.out.println("Portfolio updated successfully.");
    }

	public Object getPortfolio() {
		return portfolio;
	}
}
