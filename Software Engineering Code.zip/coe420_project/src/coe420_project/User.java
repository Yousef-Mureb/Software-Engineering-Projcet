	package coe420_project;
	
	public class User {
	   private String username;
	   private String passwordHash; // Store hashed password
	   private String userType; // "company" or "employee"
	
	
	   public User(String username, String passwordHash, String userType) {
	       this.username = username;
	       this.passwordHash = passwordHash;
	       this.userType = userType;
	   }
	
	
	   // Getters and setters
	   public String getUsername() {
	       return username;
	   }
	
	
	   public String getPasswordHash() {
	       return passwordHash;
	   }
	
	
	   public String getUserType() {
	       return userType;
	   }
	}
