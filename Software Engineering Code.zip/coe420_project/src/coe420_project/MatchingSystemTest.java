package coe420_project;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


class MatchingSystemTest {
    private MatchingSystem matchingSystem;
    private UserManager userManagerMock;
    private JobFeed jobListingSystemMock;
    private final ByteArrayOutputStream outContent = new ByteArrayOutputStream();

    @BeforeEach
    void setUp() {
        matchingSystem = new MatchingSystem();
        userManagerMock = new UserManager();
        jobListingSystemMock = new JobFeed();
        System.setOut(new PrintStream(outContent));
    }

    @Test
    void testMatchJobsWithPortfolio() {
        String username = "user123";
        Portfolio portfolioMock = new Portfolio();
        portfolioMock.setEducation(Arrays.asList("Bachelor's Degree"));
        portfolioMock.setGPA("3.5");
        portfolioMock.setExperience(Arrays.asList("2 years"));
        Job matchingJob = new Job("Software Developer", "Develop software", "2 years", "3.5", "Bachelor's Degree", "New York");
        matchingSystem.matchJobsWithPortfolio(username, userManagerMock, jobListingSystemMock);
        
        String expectedOutput = "Matching jobs for " + username + ":\n" + matchingJob + "\n";
        assertEquals(expectedOutput, outContent.toString());
    }

    // Additional test cases...
}
