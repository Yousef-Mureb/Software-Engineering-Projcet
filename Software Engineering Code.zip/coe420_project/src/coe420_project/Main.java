package coe420_project;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UserManager userManager = new UserManager();
        JobFeed jobListingSystem = new JobFeed();
        PortfolioBuilder portfolioBuilder = new PortfolioBuilder();
        MatchingSystem matchingSystem = new MatchingSystem();

        boolean isLoggedin = false;
        String loggedInUser = ""; // To store the username of the logged-in user
        String loggedInUserType = ""; // To store the type of the logged-in user

        while (true) {
            if (!isLoggedin) {
                System.out.println("\n1. Create User\n2. Login\n3. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        System.out.print("Enter username: ");
                        String createUser = scanner.nextLine();
                        System.out.print("Enter password: ");
                        String createPass = scanner.nextLine();
                        System.out.print("Enter user type (company/employee): ");
                        String userType = scanner.nextLine();
                        userManager.createUser(createUser, createPass, userType);
                        break;
                    case 2:
                        System.out.print("Enter username: ");
                        String loginUser = scanner.nextLine();
                        System.out.print("Enter password: ");
                        String loginPass = scanner.nextLine();
                        if (userManager.login(loginUser, loginPass)) {
                            isLoggedin = true;
                            loggedInUser = loginUser;
                            loggedInUserType = userManager.getUserType(loginUser);
                        }
                        break;
                    case 3:
                        System.out.println("Exiting...");
                        scanner.close();
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } else {
                System.out.println("Choose an option:");
                if (loggedInUserType.equals("employee")) {
                    System.out.println("1. Delete User\n2. Manage Portfolio\n3. View Portfolio\n4. View Jobs\n5. ApplyForJob\n6. Logout\n7. Exit");
                } else if (loggedInUserType.equals("company")) {
                    System.out.println("1. Delete User\n2. Post Job\n3. View Jobs\n4. Logout\n5. Exit");
                }

                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine();

                switch (choice) {
                    case 1:
                        System.out.print("Enter username to delete: ");
                        String deleteUser = scanner.nextLine();
                        userManager.deleteUser(deleteUser);
                        break;
                    case 2:
                        if (loggedInUserType.equals("employee")) {
                            System.out.println("Portfolio Options:");
                            System.out.println("1. Create Portfolio");
                            System.out.println("2. Edit Portfolio");
                            int portfolioChoice = scanner.nextInt();
                            scanner.nextLine();

                            switch (portfolioChoice) {
                                case 1:
                                    System.out.print("Enter education detail: ");
                                    String education = scanner.nextLine();
                                    System.out.print("Enter skills: ");
                                    String skill = scanner.nextLine();
                                    System.out.print("Enter experience detail: ");
                                    String experience = scanner.nextLine();
                                    System.out.println("Enter GPA: ");
                                    String gpa = scanner.nextLine();                                
                                    userManager.addToPortfolio(loggedInUser, education, skill, experience, gpa);
                                    break;
                                case 2:
                                    if (loggedInUserType.equals("employee")) {
                                        Portfolio existingPortfolio = userManager.getPortfolio(loggedInUser);
                                        if (existingPortfolio == null) {
                                            System.out.println("No existing portfolio. Creating a new one.");
                                            existingPortfolio = new Portfolio();
                                        }
                                        else if(existingPortfolio!=null) {
                                        portfolioBuilder.buildPortfolio(existingPortfolio);
                                        userManager.updatePortfolio(loggedInUser, portfolioBuilder.getPortfolio());
                                        }
                                    } else {
                                        System.out.println("Only employees can edit portfolios.");
                                    }
                                    break;
                                default:
                                    System.out.println("Invalid choice. Please try again.");
                                    break;
                            }
                        } else {
                            // Handle company job management if needed
                        	System.out.print("Enter job title: ");
                            String title = scanner.nextLine();
                            System.out.print("Enter job details: ");
                            String jobDetails = scanner.nextLine();
                            System.out.print("Enter required work years: ");
                            String workYears = scanner.nextLine();
                            System.out.print("Enter required GPA: ");
                            String gpa = scanner.nextLine();
                            System.out.print("Enter required education: ");
                            String education = scanner.nextLine();
                            System.out.print("Enter location: ");
                            String location = scanner.nextLine();

                            jobListingSystem.postJob(title, jobDetails, workYears, gpa, education, location);
                        	
           
                        }
                        break;
                    case 3:
                        if (loggedInUserType.equals("employee")) {
                            userManager.viewPortfolio(loggedInUser);
                        } else {
                            // Handle company view job if needed
                           // System.out.println("Company view job not implemented yet.");
                            jobListingSystem.displayJobs();
                        }
                        break;
                    case 4:
                        if (loggedInUserType.equals("employee")) {
                            jobListingSystem.displayJobs();
                        } else {
                            // Handle company job-related functionality if needed
                        	
                        	 isLoggedin = false;
                             loggedInUser = "";
                             loggedInUserType = "";
                             break;
               
                            //System.out.println("Company job-related functionality not implemented yet.");
                        }
                        break;
                        
                    case 5:
                    	if (loggedInUserType.equals("employee")) {
                    	matchingSystem.matchJobsWithPortfolio(loggedInUser, userManager, jobListingSystem);
                    }
                    else
                    {
                    	 System.out.println("Exiting...");
                         scanner.close();
                         System.exit(0);
                         break;
                    }
                    	break;
                    	
                    	
                    case 6:
                        isLoggedin = false;
                        loggedInUser = "";
                        loggedInUserType = "";
                        break;
                    case 7:
                        System.out.println("Exiting...");
                        scanner.close();
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        }
    }
}
