package coe420_project;

import java.util.HashMap;
import java.util.Map;

public class UserManager {
    private static Map<String, User> users;
    private static Map<String, Portfolio> portfolios;

    public UserManager() {
        users = new HashMap<>();
        portfolios = new HashMap<>();
    }

    public static boolean createUser(String username, String passwordHash, String userType) {
        if (users.containsKey(username)) {
            System.out.println("User already exists.");
            return false;
        }

        users.put(username, new User(username, passwordHash, userType));
        portfolios.put(username, new Portfolio());
        System.out.println("User created successfully.");
        return true;
    }

    public void deleteUser(String username) {
        if (users.containsKey(username)) {
            users.remove(username);
            portfolios.remove(username);
            System.out.println("User deleted successfully.");
        } else {
            System.out.println("User not found.");
        }
    }

    public static boolean login(String username, String password) {
        if (users.containsKey(username)) {
            User user = users.get(username);
            if (user.getPasswordHash().equals(password)) {
                System.out.println("Login successful.");
                return true;
            } else {
                System.out.println("Invalid password.");
            }
        } else {
            System.out.println("User not found.");
        }
        return false;
    }

    public String getUserType(String username) {
        if (users.containsKey(username)) {
            return users.get(username).getUserType();
        }
        return "";
    }

    public void addToPortfolio(String username, String education, String skill, String experience, String gpa) {
        if (portfolios.containsKey(username)) {
            Portfolio portfolio = portfolios.get(username);
            portfolio.addEducation(education);
            portfolio.addSkill(skill);
            portfolio.addExperience(experience);
            portfolio.setGPA(gpa); // Set the GPA
            System.out.println("Portfolio updated successfully.");
        } else {
            System.out.println("User not found.");
        }
    }

    public void viewPortfolio(String username) {
        if (portfolios.containsKey(username)) {
            System.out.println("Portfolio for " + username + ":");
            portfolios.get(username).display();
        } else {
            System.out.println("User not found.");
        }
    }

    public Portfolio getPortfolio(String loggedInUser) {
        if (portfolios.containsKey(loggedInUser)) {
            return portfolios.get(loggedInUser);
        } else {
            System.out.println("User not found.");
            return null;
        }
    }

    public void updatePortfolio(String loggedInUser, Object object) {
        if (portfolios.containsKey(loggedInUser)) {
            portfolios.put(loggedInUser, (Portfolio) object);
            System.out.println("Portfolio updated successfully.");
        } else {
            System.out.println("User not found.");
        }
    }
}
