package coe420_project;

import java.util.ArrayList;
import java.util.List;
public class JobFeed
{
   private List<Job> jobList;
   public JobFeed() {
       this.jobList = new ArrayList<>();
   }
   public void postJob(String title, String jobdetails, String workyears, String GPA, String education, String location) {
       Job job = new Job(title, jobdetails, workyears, GPA, education, location);
       jobList.add(job);
       System.out.println("Job posted successfully!\n");
   }
   public void displayJobs() {
       if (jobList.isEmpty()) {
           System.out.println("No jobs posted yet.\n");
       } else {
           System.out.println("Current Job Listings:");
           for (Job job : jobList) {
               System.out.println("------------------------------");
               System.out.println(job);
               System.out.println("------------------------------");
           }
       }
   }
public List<Job> getJobList() {
	return jobList;
}
public void setJobList(List<Job> jobList) {
	this.jobList = jobList;
}
}
