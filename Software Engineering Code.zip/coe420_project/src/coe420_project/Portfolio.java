package coe420_project;

import java.util.ArrayList;
import java.util.List;




public class Portfolio {
   private List<String> education;
   private List<String> skills;
   private List<String> experience;
   private String GPA;


   public Portfolio() {
       education = new ArrayList<>();
       skills = new ArrayList<>();
       experience = new ArrayList<>();
   }


   // Methods to add education, skills, experience
   public void addEducation(String educationDetail) {
       education.add(educationDetail);
   }


   public void addSkill(String skill) {
       skills.add(skill);
   }


   public void addExperience(String experienceDetail) {
       experience.add(experienceDetail);
   }
   
   public void setGPA(String gpa) {
       this.GPA = gpa;
   }

   public void setEducation(String education) {
       this.education.clear(); 
       this.education.add(education);
   }


   public void display() {
       System.out.println("Education: " + education);
       System.out.println("Skills: " + skills);
       System.out.println("Experience: " + experience);
       System.out.println("GPA: " + GPA);
   }


public List<String> getEducation() {
	return education;
}


public void setEducation(List<String> education) {
	this.education = education;
}


public List<String> getSkills() {
	return skills;
}


public void setSkills(List<String> skills) {
	this.skills = skills;
}


public List<String> getExperience() {
	return experience;
}


public void setExperience(List<String> experience) {
	this.experience = experience;
}


public String getGPA() {
	return GPA;
}
   
}
