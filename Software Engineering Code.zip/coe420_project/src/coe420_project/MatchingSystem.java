package coe420_project;

public class MatchingSystem {

    // Method to match a user's portfolio with job listings
    public void matchJobsWithPortfolio(String username, UserManager userManager, JobFeed jobListingSystem) {
        Portfolio portfolio = userManager.getPortfolio(username);
        if (portfolio == null) {
            System.out.println("No portfolio found for user: " + username);
            return;
        }
        System.out.println("Matching jobs for " + username + ":");
        for (Job job : jobListingSystem.getJobList()) {
            if (isMatch(portfolio, job)) {
                System.out.println(job);
            }
        }
    }

    // Helper method to determine if a job matches the user's portfolio
    private boolean isMatch(Portfolio portfolio, Job job) {
        // Check if any of the portfolio's education entries match the job's education requirement
        boolean matchesEducation = portfolio.getEducation().stream()
                                            .anyMatch(education -> education.equalsIgnoreCase(job.getEducation()));

        // Check if the portfolio's GPA matches the job's GPA requirement
        boolean matchesGPA = job.getGPA().equalsIgnoreCase(portfolio.getGPA());

        // Check if any of the portfolio's experience entries match the job's work years requirement
        boolean matchesExperience = portfolio.getExperience().stream()
                                             .anyMatch(experience -> experience.contains(job.getWorkyears()));

        // Additional matching criteria can be added here, such as skills

        return matchesEducation && matchesGPA && matchesExperience;
    }
}
