package coe420_project;

public class Job
{
   private String title;
   private String jobdetails;
   private String Workyears;
   private String GPA;
   private String education;
   private String location;
   public Job(String title, String jobDetails, String workyears, String gpa, String Education, String location) {
       this.title = title;
       this.jobdetails = jobDetails;
       this.Workyears = workyears;
       this.GPA = gpa;
       this.education = Education;
       this.location = location;
   }
   @Override
   public String toString() {
       return "Job Title: " + title + "\nJob Details: " + jobdetails + "\n" + "Work years: " + Workyears + "\nGPA: "+ GPA


               +"\nEducation: "+ education+ "\nLocation: " + location;
   }
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getJobdetails() {
	return jobdetails;
}
public void setJobdetails(String jobdetails) {
	this.jobdetails = jobdetails;
}
public String getWorkyears() {
	return Workyears;
}
public void setWorkyears(String workyears) {
	Workyears = workyears;
}
public String getGPA() {
	return GPA;
}
public void setGPA(String gPA) {
	GPA = gPA;
}
public String getEducation() {
	return education;
}
public void setEducation(String education) {
	this.education = education;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
  
   
}
